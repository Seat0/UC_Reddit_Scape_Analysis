import json
import os
import sys
import time
import random

# --- Path setup ---
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
src_path = os.path.join(project_root, "src")
sys.path.append(src_path)

from yars.yars import YARS
from yars.utils import display_results

# Initialize YARS
miner = YARS()


def save_to_json(data, filename):
    """Save data to a JSON file."""
    try:
        with open(filename, "w") as json_file:
            json.dump(data, json_file, indent=4)
        print(f"Data saved to {filename} ({len(data)} posts)")
    except Exception as e:
        print(f"Error saving JSON: {e}")


def scrape_subreddit(subreddit_name, limit=100, filename=None):
    """
    Scrape newest posts from a subreddit with delays to avoid 429.
    """
    if filename is None:
        filename = f"{subreddit_name}_posts.json"

    print(f"Scraping r/{subreddit_name} (limit={limit})")

    # Fetch newest posts
    try:
        subreddit_posts = miner.fetch_subreddit_posts(
            subreddit_name, limit=limit, category="new"
        )
        display_results(subreddit_posts, f"{subreddit_name.upper()} - NEW POSTS")
    except Exception as e:
        print(f"Failed to fetch posts from r/{subreddit_name}: {e}")
        return

    # Load existing data if available
    try:
        with open(filename, "r") as f:
            existing_data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        existing_data = []

    # Scrape post details
    for i, post in enumerate(subreddit_posts, start=1):
        permalink = post["permalink"]

        try:
            post_details = miner.scrape_post_details(permalink)
        except Exception as e:
            print(f"Skipping {permalink} due to error: {e}")
            time.sleep(10)  # wait longer on error
            continue

        if post_details:
            post_data = {
                "title": post.get("title", ""),
                "author": post.get("author", ""),
                "created_utc": post.get("created_utc", ""),
                "num_comments": post.get("num_comments", 0),
                "score": post.get("score", 0),
                "permalink": post.get("permalink", ""),
                "image_url": post.get("image_url", ""),
                "thumbnail_url": post.get("thumbnail_url", ""),
                "body": post_details.get("body", ""),
                "comments": post_details.get("comments", []),
            }

            existing_data.append(post_data)
            save_to_json(existing_data, filename)

        # Random delay between posts
        time.sleep(random.uniform(2, 4))

        # Take a longer break every 100 posts
        if i % 100 == 0:
            print("Cooling down for 30 seconds...")
            time.sleep(30)

    print(f"Finished scraping r/{subreddit_name}")


# --- Main Execution ---
if __name__ == "__main__":
    subreddits = ["ucr"]  # list of subreddits
    limit_per_subreddit = 500  # number of newest posts to scrape

    for subreddit in subreddits:
        scrape_subreddit(subreddit, limit=limit_per_subreddit)
        # Short cooldown between subreddits
        print("Waiting 15 seconds before next subreddit...")
        time.sleep(30)
