import json
import os
import sys
import time
import random

# --- Path setup ---
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
src_path = os.path.join(project_root, "src")
sys.path.append(src_path)

from yars.yars import YARS
from yars.utils import display_results

miner = YARS()


def save_to_json(data, filename):
    """Save data to a JSON file."""
    try:
        with open(filename, "w", encoding="utf-8") as json_file:
            json.dump(data, json_file, indent=4, ensure_ascii=False)
    except Exception as e:
        print(f"Error saving JSON: {e}")


def scrape_subreddit_posts_only(subreddit_name, limit=600, output_dir=None):
    """
    Scrape newest posts (with body text, no comments) from a subreddit.
    Each subreddit gets its own JSON file in posts_v2 directory.
    """
    if output_dir is None:
        output_dir = os.path.join(
            os.path.expanduser("~"),
            "Documents",
            "GitHub",
            "UC_Reddit_Scape_Analysis",
            "data",
            "UC_Data",
            "posts_v2_top",
        )

    os.makedirs(output_dir, exist_ok=True)
    filename = os.path.join(output_dir, f"{subreddit_name}_posts_top.json")

    print(f"Scraping r/{subreddit_name} (limit={limit})")

    try:
        subreddit_posts = miner.fetch_subreddit_posts(
            subreddit_name, limit=limit, category="top", time_filter="year"
        )
        display_results(subreddit_posts, f"{subreddit_name.upper()} - NEW POSTS")
    except Exception as e:
        print(f"Failed to fetch posts from r/{subreddit_name}: {e}")
        return

    try:
        with open(filename, "r", encoding="utf-8") as f:
            existing_data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        existing_data = []

    existing_permalinks = {p.get("permalink") for p in existing_data if p.get("permalink")}
    new_posts = []

    for i, post in enumerate(subreddit_posts, start=1):
        permalink = post.get("permalink", "")
        if not permalink or permalink in existing_permalinks:
            continue

        # Fetch post details to get the body text only (skip comments)
        try:
            post_details = miner.scrape_post_details(permalink)
            body_text = post_details.get("body", "")
        except Exception as e:
            print(f"Error fetching body for {permalink}: {e}")
            body_text = ""

        post_data = {
            "title": post.get("title", ""),
            "author": post.get("author", ""),
            "created_utc": post.get("created_utc", ""),
            "num_comments": post.get("num_comments", 0),
            "score": post.get("score", 0),
            "permalink": permalink,
            "image_url": post.get("image_url", ""),
            "thumbnail_url": post.get("thumbnail_url", ""),
            "body": body_text,
        }

        new_posts.append(post_data)
        existing_data.append(post_data)

        # Save incrementally to avoid data loss
        save_to_json(existing_data, filename)

        # Delay between post requests
        time.sleep(random.uniform(3, 6))

        if i % 100 == 0:
            print("Cooling down for 30 seconds...")
            time.sleep(50)

    if new_posts:
        print(f"Added {len(new_posts)} new posts to {filename}")
    else:
        print(f"No new posts found for r/{subreddit_name}")

    print(f"Finished scraping r/{subreddit_name} ({len(existing_data)} total posts)\n")
    time.sleep(random.uniform(3, 6))


# --- Main Execution ---
subreddits = ["berkeley"]
limit_per_subreddit = 500

for subreddit in subreddits:
    scrape_subreddit_posts_only(subreddit, limit=limit_per_subreddit)
    print("Waiting 15 seconds before next subreddit...\n")
    time.sleep(50)

#"UCDavis", "UCI", "ucmerced", "UCSantaBarbara", "UCSC" "ucsd", "ucla" , "berkeley" "ucr"

#.\.venv\Scripts\Activate.ps1